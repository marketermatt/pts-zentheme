<?php
/**
Plugin Name: Zen Theme Shortcodes
Plugin URI: http://pixelthemestudio.ca
Description: Add all the required shortcodes for the theme
Version: 1.0.0
Author: Matt
Author URI: http://www.pixelthemestudio.ca
License: GPL3
*/

/* Contact */
function contact_form( $atts, $content = null ) {
    extract(shortcode_atts(array(
        'email'      => '',
    ), $atts));

    $out = pts_contact_form($email);

    return $out;
}
add_shortcode('contactform', 'contact_form');

/* Drop cap - Green */
function pts_dropcap1( $atts, $content = null ) {
    return '<span class="dropcap1">' . do_shortcode($content) . '</span>';
}
add_shortcode('dropcap1', 'pts_dropcap1');

/* Drop cap - Grey */
function pts_dropcap2( $atts, $content = null ) {
    return '<span class="dropcap2">' . do_shortcode($content) . '</span>';
}
add_shortcode('dropcap2', 'pts_dropcap2');

/* List Styles */
add_shortcode('listgreen', 'pts_listgreen');
function pts_listgreen( $atts, $content = null ) {
    $content = str_replace('<ul>', '<ul class="green">', do_shortcode($content));
    return $content;
}

/* Quote blockquote */
function pts_quote( $atts, $content = null ) {
    return '<blockquote>' . do_shortcode($content) . '</blockquote>';
}
add_shortcode('quote', 'pts_quote');

/* Column four */
function pts_four( $atts, $content = null ) {
    return '<div class="four">' . do_shortcode($content) . '</div>';
}
add_shortcode('four', 'pts_four');

/* Column three */
function pts_three( $atts, $content = null ) {
    return '<div class="three">' . do_shortcode($content) . '</div>';
}
add_shortcode('three', 'pts_three');

/* Column two */
function pts_two( $atts, $content = null ) {
    return '<div class="two">' . do_shortcode($content) . '</div>';
}
add_shortcode('two', 'pts_two');

/* Column one */
function pts_one( $atts, $content = null ) {
    return '<div class="one">' . do_shortcode($content) . '</div>';
}
add_shortcode('one', 'pts_one');